=== BigIdeas ===
Contributors: WhatsTheBigIdea
Donate link:
Tags: BigIdeas, BuddyPress, bbPress, User Submitted Posts
Requires at least: 3.0.1
Tested up to: 5.2
Stable tag: 5.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Allows a user to post an idea to an Ideas page at /Ideas/. A BuddyPress group with bbPress forum are 
automatically created when this post is published.

== Description ==

/
  
  Ideas
   
  1. During installation, there is a prompt to auto-install: User Submitted Posts(USP), BuddyPress, bbPress.
  1. The User Submitted Posts plugin is used to provide the way for users to post an Idea.
  2. The post appears in wp-admin to be edited and published by the site admin.
  3. When published, a BuddyPress group with bbPress forum are created automatically.
  4. Ideas posts are displayed on the /ideas/ page.
  5. The Ideas page displays links to the BuddyPress group, a donate url, and has a description of the Idea. 
  6. The data contained in the ideas.xml file is displayed on the /ideas/ page.
  7. The Ideas from any other sites can be displayed on the /ideas/ page.  
 /

== Installation ==

/
  1. Use WordPress dashboard > Plugins > "Add New" to install the Ideas plugin. 
  2. Installing the plugin will prompt the install of the required plugins: User Submitted Posts(USP), BuddyPress, bbPress.
  3. In WP admin > pages, Publish the "Ideas" page, and the "New idea" page.
  4. In WP admin > appearance > menus, Create a menu and add the "Ideas" page to it so they are visible to site users.
  5. In WP admin > settings > permalinks, Set format to "Post name".
  6. In WP admin > settings > User Submitted Posts > Plugin Settings > Form Fields > Custom Field > "Display but do not require".
  7. In WP admin > settings > User Submitted Posts > Plugin Settings > Custom Field > Set "Custom Field Label" to "Donate link".
  8. In WP admin > settings > User Submitted Posts > Plugin Settings > Categories > Checkbox "Ideas".
  9. In WP admin > settings > User Submitted Posts > Plugin Settings > Users > Checkbox "Require User Login".
  10. In WP admin > setings > BuddyPress > Components > Checkbox "User Groups".
  11. To edit USP fields: WP admin > Posts > post > edit > toolbar > Options > Advanced Panels > checkbox "Custom Fields".
  12. In WP admin > settings > Ideas, you may include Ideas from other sites and request other sites include yours. 
/


== Frequently Asked Questions ==

== Screenshots ==

== Changelog ==

== Arbitrary section ==
